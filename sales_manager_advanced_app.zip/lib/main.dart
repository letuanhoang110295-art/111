import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() {
  runApp(MyApp());
}

class Product {
  int? id;
  String name;
  double price;
  int quantity;

  Product({this.id, required this.name, required this.price, required this.quantity});

  Map<String, dynamic> toMap() {
    return {'id': id, 'name': name, 'price': price, 'quantity': quantity};
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Advanced Sales Manager',
      theme: ThemeData(primarySwatch: Colors.green),
      home: ProductListPage(),
    );
  }
}

class ProductListPage extends StatefulWidget {
  @override
  _ProductListPageState createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  List<Product> products = [];
  Database? db;

  @override
  void initState() {
    super.initState();
    initDB();
  }

  Future<void> initDB() async {
    db = await openDatabase(join(await getDatabasesPath(), 'advanced_sales_manager.db'),
        onCreate: (db, version) {
      return db.execute('''CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            price REAL,
            quantity INTEGER
          )''');
    }, version: 1);
    loadProducts();
  }

  Future<void> loadProducts() async {
    final List<Map<String, dynamic>> maps = await db!.query('products');
    setState(() {
      products = List.generate(maps.length, (i) {
        return Product(
            id: maps[i]['id'],
            name: maps[i]['name'],
            price: maps[i]['price'],
            quantity: maps[i]['quantity']);
      });
    });
  }

  Future<void> addProduct(Product product) async {
    await db!.insert('products', product.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    loadProducts();
  }

  void printInvoice() async {
    final pdf = pw.Document();
    pdf.addPage(pw.Page(build: (pw.Context context) {
      return pw.Column(
        children: [
          pw.Text('Invoice', style: pw.TextStyle(fontSize: 24)),
          pw.SizedBox(height: 20),
          ...products.map((p) => pw.Text('${p.name} x${p.quantity} - \$${p.price}'))
        ],
      );
    }));
    await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Products'), actions: [
        IconButton(icon: Icon(Icons.picture_as_pdf), onPressed: printInvoice)
      ]),
      body: ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final p = products[index];
            return ListTile(
              title: Text(p.name),
              subtitle: Text('Price: \$${p.price}, Qty: ${p.quantity}'),
            );
          }),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          showDialog(
              context: context,
              builder: (context) {
                final nameCtrl = TextEditingController();
                final priceCtrl = TextEditingController();
                final qtyCtrl = TextEditingController();
                return AlertDialog(
                  title: Text('Add Product'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(controller: nameCtrl, decoration: InputDecoration(labelText: 'Name')),
                      TextField(controller: priceCtrl, decoration: InputDecoration(labelText: 'Price'), keyboardType: TextInputType.number),
                      TextField(controller: qtyCtrl, decoration: InputDecoration(labelText: 'Quantity'), keyboardType: TextInputType.number),
                    ],
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel')),
                    TextButton(
                        onPressed: () {
                          addProduct(Product(
                              name: nameCtrl.text,
                              price: double.parse(priceCtrl.text),
                              quantity: int.parse(qtyCtrl.text)));
                          Navigator.pop(context);
                        },
                        child: Text('Add'))
                  ],
                );
              });
        },
      ),
    );
  }
}
